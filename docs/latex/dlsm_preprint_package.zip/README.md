# DLSM Academic Preprint Submission Package

## Package Contents
- `main.tex` / `manuscript.tex`: Two-column IEEE/Nature-styled LaTeX manuscript source.
- `references.bib`: BibTeX citations including literature benchmark calibrations.
- `figures/`: High-resolution figures and dashboard telemetry screenshots.

## How to Compile on Overleaf (1-Click)
1. Go to [https://www.overleaf.com](https://www.overleaf.com) and log in.
2. Click **New Project** -> **Upload Project**.
3. Select this `dlsm_preprint_package.zip` file.
4. Overleaf will automatically detect `main.tex` and compile the full publication PDF with bibliography and formulas in seconds!

## How to Submit to arXiv / medRxiv / TechRxiv
1. This package adheres to standard arXiv automated TeX submission formats.
2. Upload this ZIP or its contents directly to the arXiv / medRxiv submission portal.
